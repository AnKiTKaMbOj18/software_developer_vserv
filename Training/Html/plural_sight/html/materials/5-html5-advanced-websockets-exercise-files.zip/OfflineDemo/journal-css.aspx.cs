﻿
namespace OfflineDemo
{
    public partial class journal_css : NoCachePage { }
}