﻿
namespace OfflineDemo
{
    public partial class update_manual : NoCachePage { }
}