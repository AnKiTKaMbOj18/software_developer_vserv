﻿namespace OfflineDemo
{
    public partial class journal_manifest : NoCachePage { }
}